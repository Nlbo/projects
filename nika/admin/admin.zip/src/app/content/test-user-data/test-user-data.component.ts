import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-user-data',
  templateUrl: './test-user-data.component.html',
  styleUrls: ['./test-user-data.component.css']
})
export class TestUserDataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
