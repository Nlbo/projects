import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portfolio-preview',
  templateUrl: './portfolio-preview.component.html',
  styleUrls: ['./portfolio-preview.component.css']
})
export class PortfolioPreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
