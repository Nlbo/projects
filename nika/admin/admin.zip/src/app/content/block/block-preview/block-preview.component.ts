import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block-preview',
  templateUrl: './block-preview.component.html',
  styleUrls: ['./block-preview.component.css']
})
export class BlockPreviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
