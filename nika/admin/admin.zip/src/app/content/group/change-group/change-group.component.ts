import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-group',
  templateUrl: './change-group.component.html',
  styleUrls: ['./change-group.component.css']
})
export class ChangeGroupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
