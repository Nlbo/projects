module.exports = {
    getGroup: (req,res) => {},
    addGroup: (req,res) => {},
    changeGroup: (req,res) => {},
    deleteGroup: (req,res) => {}
};
