module.exports = {
    port: 3000,
    protocol: 'http',
    host: 'localhost',
    mongoUrl: "../mongodb://localhost:27017/nika",
    jwt_key: 'erik'
};

